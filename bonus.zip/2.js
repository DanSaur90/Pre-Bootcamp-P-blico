var needle;
test();
function test(){
    var needle;
    needle = 'magnet';
    console.log(needle); //magnet

}
needle = 'haystack';