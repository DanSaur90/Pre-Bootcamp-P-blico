var dojo;
dojo = "san jose";
console.log(dojo); //san jose
learn();
function learn() {
    var dojo
    dojo = "seattle";
    console.log(dojo); //seattle
    dojo = "burbank";
    console.log(dojo); // burbank
}
console.log(dojo);