var hello;
console.log(hello);              //undefined                     
hello = 'world';  